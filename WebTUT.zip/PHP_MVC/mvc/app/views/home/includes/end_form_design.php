      </div>
        </div><?php if(!isset($table)){ ?>
          <div class="row align-item-center col-lg-6 d-sm-none d-lg-block">
            <div class="about-img">
              <img src="\PHP_MVC/mvc/public/img/whitepages-logo.png" class="img-fluid rounded b-shadow-a" alt="">
            </div>
          </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
</div>