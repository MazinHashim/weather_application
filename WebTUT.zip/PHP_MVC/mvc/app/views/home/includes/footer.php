
    <script src="\PHP_MVC/mvc/public/js/jquery.min.js"></script>
    <script src="\PHP_MVC/mvc/public/js/bootstrap.min.js"></script>
    <script src="\PHP_MVC/mvc/public/js/typed.min.js"></script>
    <script src="\PHP_MVC/mvc/public/js/script.js"></script>
</body>
</html>